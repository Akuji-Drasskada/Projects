﻿using CMCS_PART_3.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMCS_PART_3.Controllers
{
    public class WorkClaimController : Controller
    {
        // Temporary in-memory data store for work claims (replace with database in real application)
        private static List<WorkClaim> workClaims = new List<WorkClaim>
        {
            new WorkClaim { Id = 1, Status = "Pending", Programme = "Bachelor of Science", Name = "John Doe", Email = "john.doe@example.com", Department = "Computer Science", HoursWorked = 20, HourlyRate = 15 },
            new WorkClaim { Id = 2, Status = "Approved", Programme = "Master of Arts", Name = "Jane Smith", Email = "jane.smith@example.com", Department = "Literature", HoursWorked = 15, HourlyRate = 20 }
        };

        // Index action - list all work claims
        public IActionResult Index()
        {
            return View(workClaims);
        }

        // View details of a specific work claim
        public IActionResult Details(int id)
        {
            var workClaim = workClaims.FirstOrDefault(w => w.Id == id);
            if (workClaim == null)
            {
                return NotFound();
            }
            return View(workClaim);
        }

        // Create a new work claim (GET)
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // Handle the submission of the new work claim form (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(WorkClaim model)
        {
            if (ModelState.IsValid)
            {
                model.Id = workClaims.Count + 1; // Automatically assign the next available Id
                workClaims.Add(model); // In a real application, save to the database
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // Edit an existing work claim (GET)
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var workClaim = workClaims.FirstOrDefault(w => w.Id == id);
            if (workClaim == null)
            {
                return NotFound();
            }
            return View(workClaim);
        }

        // Handle the submission of the edit form (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, WorkClaim model)
        {
            var existingClaim = workClaims.FirstOrDefault(w => w.Id == id);
            if (existingClaim == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                existingClaim.Status = model.Status;
                existingClaim.Programme = model.Programme;
                existingClaim.Name = model.Name;
                existingClaim.Email = model.Email;
                existingClaim.Department = model.Department;
                existingClaim.HoursWorked = model.HoursWorked;
                existingClaim.HourlyRate = model.HourlyRate;
                existingClaim.AdditionalNotes = model.AdditionalNotes;
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // Delete a work claim (GET)
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var workClaim = workClaims.FirstOrDefault(w => w.Id == id);
            if (workClaim == null)
            {
                return NotFound();
            }
            return View(workClaim);
        }

        // Confirm deletion of a work claim (POST)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var workClaim = workClaims.FirstOrDefault(w => w.Id == id);
            if (workClaim == null)
            {
                return NotFound();
            }

            workClaims.Remove(workClaim); // In real application, remove from the database
            return RedirectToAction(nameof(Index));
        }
    }
}
