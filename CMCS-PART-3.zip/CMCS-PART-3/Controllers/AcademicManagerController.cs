﻿using Microsoft.AspNetCore.Mvc;
using CMCS_PART_3.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMCS_PART_3.Controllers
{
    public class AcademicManagerController : Controller
    {
        // Temporary in-memory data store for academic managers
        private static List<AcademicManager> academicManagers = new()
        {
            new AcademicManager { Name = "Dr. Jane Smith", Id = Guid.NewGuid(), Email = "jane.smith@university.com", Role = "Head of Department" },
            new AcademicManager { Name = "Dr. John Doe", Id = Guid.NewGuid(), Email = "john.doe@university.com", Role = "Programme Coordinator" }
        };

        // Index action - list all academic managers
        public IActionResult Index()
        {
            return View(academicManagers);
        }

        // View details of a specific academic manager
        public IActionResult Details(Guid id) // Changed to Guid
        {
            var manager = academicManagers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }
            return View(manager);
        }

        // Create new academic manager (GET)
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // Handle the submission of the new academic manager form (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(AcademicManager model)
        {
            if (ModelState.IsValid)
            {
                academicManagers.Add(model); // Add new manager
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // Edit an existing academic manager (GET)
        [HttpGet]
        public IActionResult Edit(Guid id) // Changed to Guid
        {
            var manager = academicManagers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }
            return View(manager);
        }

        // Handle the submission of the edit form (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Guid id, AcademicManager model)
        {
            if (id != model.Id)
            {
                return BadRequest("The provided ID does not match the model ID.");
            }

            var manager = academicManagers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound("The specified Academic Manager was not found.");
            }

            if (ModelState.IsValid)
            {
                manager.Name = model.Name;
                manager.Email = model.Email;
                manager.Role = model.Role;
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        // Delete an academic manager (GET)
        [HttpGet]
        public IActionResult Delete(Guid id) // Changed to Guid
        {
            var manager = academicManagers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }
            return View(manager);
        }

        // Confirm deletion of an academic manager (POST)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(Guid id) // Changed to Guid
        {
            var manager = academicManagers.FirstOrDefault(m => m.Id == id);
            if (manager == null)
            {
                return NotFound();
            }

            academicManagers.Remove(manager);
            return RedirectToAction(nameof(Index));
        }
    }
}
