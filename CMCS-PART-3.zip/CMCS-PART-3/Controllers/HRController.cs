﻿using CMCS_PART_3.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace CMCS.Controllers
{
    public class HRController : Controller
    {
        // Simulated static data
        private static List<HRClaimModel> claims = new List<HRClaimModel>
        {
            new HRClaimModel { ClaimId = 1, LecturerName = "John Doe", HoursWorked = 10, HourlyRate = 20 },
            new HRClaimModel { ClaimId = 2, LecturerName = "Jane Smith", HoursWorked = 15, HourlyRate = 25 }
        };

        private static List<HRLecturerModel> lecturers = new List<HRLecturerModel>
        {
            new HRLecturerModel { LecturerId = 1, Name = "John Doe", Email = "john.doe@example.com", ContactNumber = "1234567890" },
            new HRLecturerModel { LecturerId = 2, Name = "Jane Smith", Email = "jane.smith@example.com", ContactNumber = "0987654321" }
        };

        // Dashboard
        public IActionResult Dashboard()
        {
            return View(claims);
        }

        // Approve Claim
        [HttpPost]
        public IActionResult ApproveClaim(int id)
        {
            var claim = claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Approved";
            }
            return RedirectToAction(nameof(Dashboard));
        }

        // Reject Claim
        [HttpPost]
        public IActionResult RejectClaim(int id, string notes)
        {
            var claim = claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Rejected";
                claim.Notes = notes;
            }
            return RedirectToAction(nameof(Dashboard));
        }

        // Manage Lecturers
        public IActionResult ManageLecturers()
        {
            return View(lecturers);
        }

        // Update Lecturer (GET)
        [HttpGet]
        public IActionResult UpdateLecturer(int id)
        {
            var lecturer = lecturers.FirstOrDefault(l => l.LecturerId == id);
            if (lecturer == null) return NotFound();
            return View(lecturer);
        }

        // Update Lecturer (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateLecturer(HRLecturerModel model)
        {
            var lecturer = lecturers.FirstOrDefault(l => l.LecturerId == model.LecturerId);
            if (lecturer == null) return NotFound();

            if (ModelState.IsValid)
            {
                lecturer.Name = model.Name;
                lecturer.Email = model.Email;
                lecturer.ContactNumber = model.ContactNumber;
                return RedirectToAction(nameof(ManageLecturers));
            }

            return View(model);
        }

        // Generate Reports
        public IActionResult GenerateReports()
        {
            var reports = claims.Where(c => c.Status == "Approved")
                                .Select(c => new HRReportModel
                                {
                                    LecturerName = c.LecturerName,
                                    TotalPayment = c.FinalPayment,
                                    Status = c.Status,
                                    Notes = c.Notes
                                }).ToList();

            return View(reports);
        }
    }
}
