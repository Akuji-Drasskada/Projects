﻿using CMCS_PART_3.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CMCS_PART_3.Controllers
{
    public class LecturersController : Controller
    {
        // Sample lecturer data (in a real app, you would retrieve this from a database)
        private static List<Lecturers> _lecturers = new List<Lecturers>
        {
            new Lecturers { Id = 1, Name = "John Doe", Email = "john.doe@example.com", Department = "Computer Science" },
            new Lecturers { Id = 2, Name = "Jane Smith", Email = "jane.smith@example.com", Department = "Mathematics" }
        };

        // Index action to display a list of lecturers
        public IActionResult Index()
        {
            return View(_lecturers); // Pass the lecturer list to the view
        }

        // View details for a specific lecturer
        public IActionResult Details(int id)
        {
            var lecturer = _lecturers.Find(l => l.Id == id);
            if (lecturer == null)
            {
                return NotFound(); // If no lecturer is found, return a 404
            }
            return View(lecturer); // Pass the lecturer to the details view
        }

        // Action to create a new lecturer (GET form)
        public IActionResult Create()
        {
            return View(); // Return the view without a model (empty form)
        }

        // Handle the form submission for creating a new lecturer
        [HttpPost]
        public IActionResult Create(Lecturers lecturer)
        {
            if (ModelState.IsValid)
            {
                // Optionally validate email if you want custom logic
                if (!lecturer.IsValidEmail())
                {
                    ModelState.AddModelError("Email", "Email is not valid.");
                    return View(lecturer); // Return the model with error
                }

                // Add the new lecturer to the list (this would be a database in a real application)
                lecturer.Id = _lecturers.Count + 1; // Ensure the lecturer has a unique ID
                _lecturers.Add(lecturer);

                // Redirect to the index page after successful creation
                return RedirectToAction(nameof(Index));
            }

            // If the model state is invalid, return to the create form with validation errors
            return View(lecturer);
        }

        // Edit a lecturer (GET form)
        public IActionResult Edit(int id)
        {
            var lecturer = _lecturers.Find(l => l.Id == id);
            if (lecturer == null)
            {
                return NotFound(); // If no lecturer is found, return a 404
            }
            return View(lecturer); // Return the existing lecturer data to the form
        }

        // Handle the form submission for editing a lecturer
        [HttpPost]
        public IActionResult Edit(Lecturers lecturer)
        {
            if (ModelState.IsValid)
            {
                var existingLecturer = _lecturers.Find(l => l.Id == lecturer.Id);
                if (existingLecturer == null)
                {
                    return NotFound(); // If no lecturer is found to edit, return a 404
                }

                // Update the lecturer's details
                existingLecturer.Name = lecturer.Name;
                existingLecturer.Email = lecturer.Email;
                existingLecturer.Department = lecturer.Department;

                // Redirect to the list of lecturers after editing
                return RedirectToAction(nameof(Index));
            }

            // If model is invalid, return to the edit form with validation errors
            return View(lecturer);
        }

        // Delete a lecturer (GET confirmation form)
        public IActionResult Delete(int id)
        {
            var lecturer = _lecturers.Find(l => l.Id == id);
            if (lecturer == null)
            {
                return NotFound(); // If no lecturer is found, return a 404
            }
            return View(lecturer); // Return the lecturer details to confirm deletion
        }

        // Handle the deletion of a lecturer (POST)
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var lecturer = _lecturers.Find(l => l.Id == id);
            if (lecturer == null)
            {
                return NotFound(); // If no lecturer is found, return a 404
            }
            _lecturers.Remove(lecturer); // Remove the lecturer from the list (this would be a database operation in a real app)
            return RedirectToAction(nameof(Index)); // Redirect to the index page after deletion
        }
    }
}
