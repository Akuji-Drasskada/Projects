﻿using CMCS_PART_3.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace CMCS_PART_3.Controllers
{
    public class CoordinatorsApprovalsController : Controller
    {
        private static List<CoordinatorsApprovals> pendingClaims = new List<CoordinatorsApprovals>
        {
            new CoordinatorsApprovals { Id = Guid.NewGuid(), Name = "John Doe", Department = "Computer Science", HoursWorked = 40, HourlyRate = 20, IsApproved = false, DateSubmitted = DateTime.Now },
            new CoordinatorsApprovals { Id = Guid.NewGuid(), Name = "Jane Smith", Department = "Mathematics", HoursWorked = 35, HourlyRate = 25, IsApproved = false, DateSubmitted = DateTime.Now }
        };

        public IActionResult Index()
        {
            return View(pendingClaims);
        }

        [HttpPost]
        public IActionResult ApproveClaim(Guid id)
        {
            var claim = pendingClaims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.IsApproved = true;
                claim.DateApproved = DateTime.Now;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult RejectClaim(Guid id)
        {
            var claim = pendingClaims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.IsApproved = false;
                // Optionally, you can clear out DateApproved when rejecting
                claim.DateApproved = null;
            }
            return RedirectToAction("Index");
        }
    }
}
