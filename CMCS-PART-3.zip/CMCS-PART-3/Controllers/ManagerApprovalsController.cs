﻿using CMCS_PART_3.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace CMCS_PART_3.Controllers
{
    public class ManagerApprovalsController : Controller
    {
        // Simulating a database with a static list of claims for simplicity
        private static List<ManagerApprovals> pendingClaims = new List<ManagerApprovals>
        {
            new ManagerApprovals { Id = Guid.NewGuid(), Name = "Tom Green", Department = "Physics", HoursWorked = 40, HourlyRate = 30, IsApproved = false, DateSubmitted = DateTime.Now },
            new ManagerApprovals { Id = Guid.NewGuid(), Name = "Alice Blue", Department = "Chemistry", HoursWorked = 40, HourlyRate = 28, IsApproved = false, DateSubmitted = DateTime.Now }
        };

        public IActionResult Index()
        {
            return View(pendingClaims); // Returns the list of pending claims
        }

        // Action to approve a claim
        [HttpPost]
        public IActionResult ApproveClaim(Guid id)
        {
            var claim = pendingClaims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.IsApproved = true;
                claim.DateApproved = DateTime.Now;
            }
            return RedirectToAction("Index");
        }

        // Action to reject a claim
        [HttpPost]
        public IActionResult RejectClaim(Guid id)
        {
            var claim = pendingClaims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.IsApproved = false;
            }
            return RedirectToAction("Index");
        }
    }
}
