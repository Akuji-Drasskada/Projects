using System.Diagnostics;
using CMCS_PART_3.Models;
using Microsoft.AspNetCore.Mvc;

namespace CMCS_PART_3.Controllers
{
    public class HomeController : Controller
    {
        // Index action - usually the home page or landing page
        public IActionResult Index()
        {
            return View();
        }

        // Privacy action - a page with privacy policy details
        public IActionResult Privacy()
        {
            return View();
        }

        // Error handling action
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            return View(new ErrorViewModel { RequestId = requestId });
        }
    }
}
