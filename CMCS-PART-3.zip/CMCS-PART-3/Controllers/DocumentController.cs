﻿using CMCS_PART_3.Models;
using Microsoft.AspNetCore.Mvc;

public class DocumentController : Controller
{
    private readonly DocumentService _documentService;

    // Constructor to inject the DocumentService
    public DocumentController(DocumentService documentService)
    {
        _documentService = documentService;
    }

    // Index Action
    public IActionResult Index()
    {
        var documents = _documentService.GetAllDocuments();
        return View(documents);
    }

    // Create Action (GET)
    public IActionResult Create()
    {
        return View(); // This will show a form for creating a new document
    }

    // Create Action (POST)
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Document document)
    {
        if (ModelState.IsValid)
        {
            // Add document creation logic here, e.g., save to the database
            _documentService.AddDocument(document);
            return RedirectToAction("Index"); // Redirect to the Index page after creation
        }
        return View(document); // If the model is not valid, return the same form
    }

    // Other actions (Details, Edit, Delete)
    public IActionResult Details(int id)
    {
        var document = _documentService.GetDocumentById(id);
        if (document == null)
        {
            return NotFound();
        }
        return View(document);
    }

    public IActionResult Edit(int id)
    {
        var document = _documentService.GetDocumentById(id);
        if (document == null)
        {
            return NotFound();
        }
        return View(document);
    }

    public IActionResult Delete(int id)
    {
        var document = _documentService.GetDocumentById(id);
        if (document == null)
        {
            return NotFound();
        }
        return View(document);
    }
}
