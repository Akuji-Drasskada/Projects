﻿using Microsoft.AspNetCore.Mvc;
using CMCS_PART_3.Models;
using System.Collections.Generic;
using System.Linq;

namespace CMCS_PART_3.Controllers
{
    public class ClaimsController : Controller
    {
        // Temporary in-memory data store for claims (replace with a database in a real app)
        private static List<Claim> claims = new List<Claim>
        {
            new Claim("Approved", "Bachelor of Science", "John Doe", "john.doe@example.com", "Computer Science"),
            new Claim("Pending", "Master of Arts", "Jane Smith", "jane.smith@example.com", "Literature")
        };

        // Index action - list all claims
        public IActionResult Index()
        {
            return View(claims);
        }

        // View details of a specific claim
        public IActionResult Details(int id)
        {
            var claim = claims.ElementAtOrDefault(id);
            if (claim == null)
            {
                return NotFound();
            }
            return View(claim);
        }

        // Create a new claim
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // Handle the submission of the new claim form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Claim model)
        {
            if (ModelState.IsValid)
            {
                claims.Add(model); // In real apps, save to the database
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // Edit an existing claim
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var claim = claims.ElementAtOrDefault(id);
            if (claim == null)
            {
                return NotFound();
            }
            return View(claim);
        }

        // Handle the submission of the edit form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Claim model)
        {
            if (id < 0 || id >= claims.Count)
            {
                return NotFound();
            }

            var existingClaim = claims.ElementAt(id);
            if (existingClaim == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                existingClaim.Status = model.Status;
                existingClaim.Programme = model.Programme;
                existingClaim.Name = model.Name;
                existingClaim.Email = model.Email;
                existingClaim.Department = model.Department;
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // Delete a claim
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var claim = claims.ElementAtOrDefault(id);
            if (claim == null)
            {
                return NotFound();
            }
            return View(claim);
        }

        // Confirm deletion of a claim
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var claim = claims.ElementAtOrDefault(id);
            if (claim == null)
            {
                return NotFound();
            }

            claims.RemoveAt(id); // In real apps, remove from the database
            return RedirectToAction(nameof(Index));
        }
    }
}