﻿using Microsoft.AspNetCore.Mvc;
using CMCS_PART_3.Models;

namespace CMCS_PART_3.Controllers
{
    public class ProgCoordinatorController : Controller
    {
        // In-memory storage for the sake of demonstration (you should replace it with a database or service)
        private static List<ProgrammeCoordinator> coordinators = new List<ProgrammeCoordinator>
        {
            new ProgrammeCoordinator { Programme = "Computer Science", Name = "John Doe", Email = "john.doe@example.com", Id = 1 },
            new ProgrammeCoordinator { Programme = "Mathematics", Name = "Jane Smith", Email = "jane.smith@example.com", Id = 2 }
        };

        // Index Action to display all program coordinators
        public IActionResult Index()
        {
            return View(coordinators);
        }

        // Action to create a new Programme Coordinator (GET)
        public IActionResult Create()
        {
            return View();
        }

        // Action to handle the POST request when creating a new Programme Coordinator
        [HttpPost]
        public IActionResult Create(ProgrammeCoordinator coordinator)
        {
            if (ModelState.IsValid)
            {
                // Add the new coordinator to the list (replace with database logic)
                coordinator.Id = coordinators.Count + 1; // Generate a new ID (you can implement a better ID generation method)
                coordinators.Add(coordinator);

                // Redirect to the Index view to see the updated list
                return RedirectToAction(nameof(Index));
            }

            // If the model is invalid, return to the Create view with validation errors
            return View(coordinator);
        }

        // Action to edit an existing Programme Coordinator (GET)
        public IActionResult Edit(int id)
        {
            var coordinator = coordinators.FirstOrDefault(c => c.Id == id);
            if (coordinator == null)
            {
                return NotFound(); // Return a 404 if the coordinator is not found
            }

            return View(coordinator);
        }

        // Action to handle the POST request when editing an existing Programme Coordinator
        [HttpPost]
        public IActionResult Edit(ProgrammeCoordinator coordinator)
        {
            if (ModelState.IsValid)
            {
                var existingCoordinator = coordinators.FirstOrDefault(c => c.Id == coordinator.Id);
                if (existingCoordinator == null)
                {
                    return NotFound(); // Return a 404 if the coordinator is not found
                }

                // Update the coordinator's details
                existingCoordinator.Programme = coordinator.Programme;
                existingCoordinator.Name = coordinator.Name;
                existingCoordinator.Email = coordinator.Email;

                // Redirect to the Index view to see the updated list
                return RedirectToAction(nameof(Index));
            }

            // If the model is invalid, return to the Edit view with validation errors
            return View(coordinator);
        }

        // Action to delete a Programme Coordinator (GET)
        public IActionResult Delete(int id)
        {
            var coordinator = coordinators.FirstOrDefault(c => c.Id == id);
            if (coordinator == null)
            {
                return NotFound(); // Return a 404 if the coordinator is not found
            }

            return View(coordinator);
        }

        // Action to handle the POST request for deleting a Programme Coordinator
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var coordinator = coordinators.FirstOrDefault(c => c.Id == id);
            if (coordinator == null)
            {
                return NotFound(); // Return a 404 if the coordinator is not found
            }

            // Remove the coordinator from the list (replace with database logic)
            coordinators.Remove(coordinator);

            // Redirect to the Index view after deletion
            return RedirectToAction(nameof(Index));
        }
    }
}
