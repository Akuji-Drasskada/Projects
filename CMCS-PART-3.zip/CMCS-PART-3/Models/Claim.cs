﻿using System.ComponentModel.DataAnnotations;

namespace CMCS_PART_3.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }

        [Required]
        public string Claimant { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Amount must be a positive number")]
        public decimal Amount { get; set; }

        [Required]
        public string Status { get; set; }

        [Required]
        public string Programme { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Department { get; set; }

        // Parameterized Constructor
        public Claim(int claimId, string claimant, decimal amount, string status, string programme, string name, string email, string department)
        {
            ClaimId = claimId;
            Claimant = claimant;
            Amount = amount;
            Status = status;
            Programme = programme;
            Name = name;
            Email = email;
            Department = department;
        }

        // Parameterless Constructor
        public Claim()
        {
        }

        // Constructor for quick creation
        public Claim(string status, string programme, string name, string email, string department)
        {
            Status = status;
            Programme = programme;
            Name = name;
            Email = email;
            Department = department;
        }
    }
}

