﻿using System;

namespace CMCS_PART_3.Models
{
    public class CoordinatorsApprovals
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public decimal HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public string AdditionalNotes { get; set; }
        public string FilePathString { get; set; }  // File associated with the claim
        public bool IsApproved { get; set; }  // Status of the claim (approved/rejected)
        public DateTime DateSubmitted { get; set; }
        public DateTime? DateApproved { get; set; }  // Date when approved (if any)
    }
}
