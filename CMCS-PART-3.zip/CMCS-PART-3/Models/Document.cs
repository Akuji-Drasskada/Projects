﻿namespace CMCS_PART_3.Models
{
    public class Document
    {
        public int Id { get; set; } // This could be an auto-generated ID
        public string Name { get; set; }
        public string Description { get; set; }
        public string FilePath { get; set; }
        public int OwnerId { get; set; }
        public string DocumentType { get; set; }
        public string Title { get; set; } // Title of the document
        public long FileSize { get; set; } // File size in bytes
        public DateTime CreatedDate { get; set; } // Date the document was created
        public string Content { get; set; } // The content of the document (if applicable)
    }
}
