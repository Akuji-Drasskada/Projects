﻿namespace CMCS_PART_3.Models
{
    public class HRReportModel
    {
        public string LecturerName { get; set; }
        public double TotalPayment { get; set; }
        public string Status { get; set; }
        public string Notes { get; set; }
    }

}
