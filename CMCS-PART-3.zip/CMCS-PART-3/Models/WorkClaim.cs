﻿using System.ComponentModel.DataAnnotations;

namespace CMCS_PART_3.Models
{
    public class WorkClaim
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Department { get; set; }

        [Required]
        public string Programme { get; set; }

        [Required]
        [Range(0.1, double.MaxValue, ErrorMessage = "Hours Worked must be greater than 0")]
        public double HoursWorked { get; set; }

        [Required]
        [Range(0.1, double.MaxValue, ErrorMessage = "Hourly Rate must be greater than 0")]
        public double HourlyRate { get; set; }

        public string Status { get; set; }
        public string AdditionalNotes { get; set; }

        public double Amount => HoursWorked * HourlyRate; // Calculate Amount
        public List<Document> Documents { get; set; } = new List<Document>();

    }
}
