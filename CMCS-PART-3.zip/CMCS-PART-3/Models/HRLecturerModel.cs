﻿namespace CMCS_PART_3.Models
{
    public class HRLecturerModel
    {
        public int LecturerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
    }
}
