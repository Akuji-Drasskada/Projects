﻿using System.ComponentModel.DataAnnotations;

namespace CMCS_PART_3.Models
{
    public class AcademicManager
    {
        /// <summary>
        /// Unique identifier for the academic manager.
        /// This will be auto-generated in the controller during creation.
        /// </summary>
        [Key] // Marks this property as the primary key (useful if using Entity Framework)
        public Guid Id { get; set; } // Changed to Guid to ensure uniqueness and avoid string-based ID generation

        /// <summary>
        /// Name of the academic manager.
        /// This field is required.
        /// </summary>
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        public string Name { get; set; }

        /// <summary>
        /// Email address of the academic manager.
        /// This field is required and must be a valid email format.
        /// </summary>
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string Email { get; set; }

        /// <summary>
        /// Role of the academic manager (e.g., Head of Department, Programme Coordinator).
        /// This field is required.
        /// </summary>
        [Required(ErrorMessage = "Role is required")]
        [StringLength(50, ErrorMessage = "Role cannot exceed 50 characters")]
        public string Role { get; set; }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public AcademicManager()
        {
            // Auto-generate the ID here in the constructor if necessary
            Id = Guid.NewGuid(); // Ensure each new manager gets a unique ID
        }

        // No need for a parameterized constructor anymore since the ID is auto-generated in the controller.
    }
}
