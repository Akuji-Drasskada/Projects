﻿namespace CMCS_PART_3.Models
{
    public class HRClaimModel
    {
        public int ClaimId { get; set; }
        public string LecturerName { get; set; }
        public double HoursWorked { get; set; }
        public double HourlyRate { get; set; }
        public double FinalPayment => HoursWorked * HourlyRate; // Auto-calculation
        public string Status { get; set; } = "Pending"; // Default status
        public string Notes { get; set; } // Notes for rejection or comments
    }
}
