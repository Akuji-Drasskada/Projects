﻿using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations; // Add for data annotations

namespace CMCS_PART_3.Models
{
    public class Lecturers
    {
        // ID and Name should be required for validation
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [EmailAddress(ErrorMessage = "Invalid email format")]
        [Required(ErrorMessage = "Email is required")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Department is required")]
        public string Department { get; set; }

        // Parameterless Constructor for model binding
        public Lecturers() { }

        // Parameterized Constructor (optional)
        public Lecturers(string name, int id, string email, string department)
        {
            Name = name;
            Id = id;
            Email = email;
            Department = department;
        }

        // Custom method for validating the email format (if necessary)
        public bool IsValidEmail()
        {
            var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(Email, emailPattern);
        }
    }
}
