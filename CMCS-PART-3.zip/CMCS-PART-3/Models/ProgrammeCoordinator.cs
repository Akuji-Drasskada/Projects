﻿using System.Text.RegularExpressions;

namespace CMCS_PART_3.Models
{
    public class ProgrammeCoordinator
    {
        public string Programme { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Id { get; set; }

        // Parameterized Constructor
        public ProgrammeCoordinator(string programme, string name, string email, int id)
        {
            Programme = programme;
            Name = name;
            Email = email;
            Id = id;
        }

        // Parameterless Constructor
        public ProgrammeCoordinator()
        {
        }

        public bool IsValidEmail()
        {
            var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(Email, emailPattern);
        }
    }
}
