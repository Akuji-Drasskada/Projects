var builder = WebApplication.CreateBuilder(args);

// Register services to the container
builder.Services.AddTransient<DocumentService>(); // Register DocumentService
builder.Services.AddControllersWithViews(); // Register controllers with views

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Define the default route, ensuring it maps correctly to the DocumentController
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Document}/{action=Index}/{id?}");

app.Run();
