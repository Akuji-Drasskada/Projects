﻿using CMCS_PART_3.Models;

public class DocumentService
{
    public List<Document> GetAllDocuments()
    {
        // Replace with your actual database fetching logic
        return new List<Document>
        {
            new Document { Id = 1, Name = "Document 1", Description = "Description 1", DocumentType = "PDF", CreatedDate = DateTime.Now },
            new Document { Id = 2, Name = "Document 2", Description = "Description 2", DocumentType = "Word", CreatedDate = DateTime.Now }
        };
    }

    public Document GetDocumentById(int id)
    {
        return GetAllDocuments().FirstOrDefault(d => d.Id == id);
    }

    internal void AddDocument(Document document)
    {
        throw new NotImplementedException();
    }
}
