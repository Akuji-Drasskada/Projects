﻿using EventEaseVenueBookingSystem.Models;
using EventEaseVenueBookingSystem.Models.ViewModels;
using EventEaseVenueBookingSystem.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventEaseVenueBookingSystem.Controllers
{
    public class BookingController : Controller
    {
        private readonly IBookingService _bookingService;
        private readonly IVenueService _venueService;
        private readonly IEventService _eventService;

        public BookingController(IBookingService bookingService, IVenueService venueService, IEventService eventService)
        {
            _bookingService = bookingService;
            _venueService = venueService;
            _eventService = eventService;
        }

        public IActionResult Index()
        {
            var bookings = _bookingService.GetAll().Select(b =>
            {
                var venue = _venueService.GetById(b.VenueId);
                var eventItem = _eventService.GetById(b.EventId);

                return new
                {
                    b.Id,
                    BookingDate = b.BookingDate.ToShortDateString(),
                    VenueName = venue?.Name ?? "Unknown Venue",
                    EventName = eventItem?.Name ?? "Unknown Event"
                };
            }).ToList();

            ViewBag.Bookings = bookings;
            return View();
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            ViewBag.Venues = _venueService.GetAll();
            ViewBag.Events = _eventService.GetAll();
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult Create(BookingViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Venues = _venueService.GetAll();
                ViewBag.Events = _eventService.GetAll();
                return View(model);
            }

            var booking = new Booking
            {
                VenueId = model.VenueId,
                EventId = model.EventId,
                BookingDate = model.BookingDate
            };

            _bookingService.Add(booking);
            TempData["SuccessMessage"] = "Booking created successfully!";
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Delete(int id)
        {
            _bookingService.Delete(id);
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            var booking = _bookingService.GetById(id);
            if (booking == null) return NotFound();

            var venue = _venueService.GetById(booking.VenueId);
            var eventItem = _eventService.GetById(booking.EventId);

            var bookingDetails = new
            {
                booking.Id,
                booking.BookingDate,
                VenueName = venue?.Name ?? "Unknown Venue",
                EventName = eventItem?.Name ?? "Unknown Event"
            };

            ViewBag.Booking = bookingDetails;
            return View();
        }
    }
}
