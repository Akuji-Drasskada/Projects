﻿using EventEaseVenueBookingSystem.Models;
using EventEaseVenueBookingSystem.Models.ViewModels;
using EventEaseVenueBookingSystem.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventEaseVenueBookingSystem.Controllers
{
    public class VenueController : Controller
    {
        private readonly IVenueService _venueService;

        public VenueController(IVenueService venueService)
        {
            _venueService = venueService;
        }

        public IActionResult Index()
        {
            return View(_venueService.GetAll());
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult Create() => View();

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult Create(VenueViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var venue = new Venue
            {
                Name = model.Name,
                Location = model.Location,
                Capacity = model.Capacity,
                ImageUrl = model.ImageUrl
            };

            _venueService.Add(venue);
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Delete(int id)
        {
            _venueService.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
