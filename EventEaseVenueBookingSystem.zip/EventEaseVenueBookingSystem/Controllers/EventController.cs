﻿using EventEaseVenueBookingSystem.Models;
using EventEaseVenueBookingSystem.Models.ViewModels;
using EventEaseVenueBookingSystem.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventEaseVenueBookingSystem.Controllers
{
    public class EventController : Controller
    {
        private readonly IEventService _eventService;

        public EventController(IEventService eventService)
        {
            _eventService = eventService;
        }

        public IActionResult Index()
        {
            return View(_eventService.GetAll());
        }

        public IActionResult Details(int id)
        {
            var evt = _eventService.GetById(id);
            if (evt == null) return NotFound();
            return View(evt);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult Create(EventViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var evt = new Event
            {
                Name = model.Name,
                Description = model.Description,
                StartDate = model.StartDate,
                EndDate = model.EndDate,
                ImageUrl = model.ImageUrl
            };

            _eventService.Add(evt);
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Delete(int id)
        {
            _eventService.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
