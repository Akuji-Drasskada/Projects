﻿using System.ComponentModel.DataAnnotations;

namespace EventEaseVenueBookingSystem.Models.ViewModels
{
    public class VenueViewModel
    {
        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [StringLength(200)]
        public string Location { get; set; } = string.Empty;

        [Required]
        [Range(10, 10000)]
        public int Capacity { get; set; }

        [Url]
        [Display(Name = "Image URL")]
        public string ImageUrl { get; set; } = string.Empty;
    }
}
