﻿using System.ComponentModel.DataAnnotations;

namespace EventEaseVenueBookingSystem.Models.ViewModels
{
    public class BookingViewModel
    {
        [Required]
        [Display(Name = "Venue")]
        public int VenueId { get; set; }

        [Required]
        [Display(Name = "Event")]
        public int EventId { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Booking Date")]
        public DateTime BookingDate { get; set; }
    }
}
