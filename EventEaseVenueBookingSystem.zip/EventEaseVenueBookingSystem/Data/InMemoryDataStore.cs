﻿using EventEaseVenueBookingSystem.Models;

namespace EventEaseVenueBookingSystem.Data
{
    public static class InMemoryDataStore
    {
        public static List<Venue> Venues { get; set; } = new()
        {
            new Venue { Id = 1, Name = "Main Hall", Location = "Cape Town", Capacity = 300, ImageUrl = "https://via.placeholder.com/150" },
            new Venue { Id = 2, Name = "Conference Room A", Location = "Johannesburg", Capacity = 120, ImageUrl = "https://via.placeholder.com/150" }
        };

        public static List<Event> Events { get; set; } = new()
        {
            new Event { Id = 1, Name = "Tech Expo", Description = "Annual tech event", StartDate = DateTime.Now, EndDate = DateTime.Now.AddDays(1), ImageUrl = "https://via.placeholder.com/150" }
        };

        public static List<Booking> Bookings { get; set; } = new()
        {
            new Booking { Id = 1, VenueId = 1, EventId = 1, BookingDate = DateTime.Today }
        };
    }
}
