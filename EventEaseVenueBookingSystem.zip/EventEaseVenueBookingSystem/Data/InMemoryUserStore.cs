﻿namespace EventEaseVenueBookingSystem.Data
{
    public static class InMemoryUserStore
    {
        public static List<(string Username, string Password, string Role)> Users = new()
        {
            ("admin", "admin123", "Admin"),
            ("user", "user123", "User")
        };
    }
}
