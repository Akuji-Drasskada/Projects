﻿using EventEaseVenueBookingSystem.Models;

namespace EventEaseVenueBookingSystem.Services.Interfaces
{
    public interface IEventService
    {
        IEnumerable<Event> GetAll();
        Event? GetById(int id);
        void Add(Event evt);
        void Delete(int id);
    }
}
