﻿using EventEaseVenueBookingSystem.Models;

namespace EventEaseVenueBookingSystem.Services.Interfaces
{
    public interface IVenueService
    {
        IEnumerable<Venue> GetAll();
        void Add(Venue venue);
        void Delete(int id);
        Venue? GetById(int id);
    }
}
