﻿using EventEaseVenueBookingSystem.Models;

namespace EventEaseVenueBookingSystem.Services.Interfaces
{
    public interface IBookingService
    {
        IEnumerable<Booking> GetAll();
        Booking? GetById(int id);
        void Add(Booking booking);
        void Delete(int id);
    }
}
