﻿using EventEaseVenueBookingSystem.Data;
using EventEaseVenueBookingSystem.Models;
using EventEaseVenueBookingSystem.Services.Interfaces;

namespace EventEaseVenueBookingSystem.Services
{
    public class VenueService : IVenueService
    {
        public IEnumerable<Venue> GetAll() => InMemoryDataStore.Venues;

        public Venue? GetById(int id) => InMemoryDataStore.Venues.FirstOrDefault(v => v.Id == id);

        public void Add(Venue venue)
        {
            venue.Id = InMemoryDataStore.Venues.Any() ? InMemoryDataStore.Venues.Max(v => v.Id) + 1 : 1;
            InMemoryDataStore.Venues.Add(venue);
        }

        public void Delete(int id)
        {
            var venue = GetById(id);
            if (venue != null) InMemoryDataStore.Venues.Remove(venue);
        }
    }
}
