﻿using EventEaseVenueBookingSystem.Data;
using EventEaseVenueBookingSystem.Models;
using EventEaseVenueBookingSystem.Services.Interfaces;

namespace EventEaseVenueBookingSystem.Services
{
    public class BookingService : IBookingService
    {
        public IEnumerable<Booking> GetAll() => InMemoryDataStore.Bookings;

        public Booking? GetById(int id) => InMemoryDataStore.Bookings.FirstOrDefault(b => b.Id == id);

        public void Add(Booking booking)
        {
            booking.Id = InMemoryDataStore.Bookings.Any() ? InMemoryDataStore.Bookings.Max(b => b.Id) + 1 : 1;
            InMemoryDataStore.Bookings.Add(booking);
        }

        public void Delete(int id)
        {
            var booking = GetById(id);
            if (booking != null) InMemoryDataStore.Bookings.Remove(booking);
        }
    }
}
