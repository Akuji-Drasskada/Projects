﻿using EventEaseVenueBookingSystem.Data;
using EventEaseVenueBookingSystem.Models;
using EventEaseVenueBookingSystem.Services.Interfaces;

namespace EventEaseVenueBookingSystem.Services
{
    public class EventService : IEventService
    {
        public IEnumerable<Event> GetAll() => InMemoryDataStore.Events;

        public Event? GetById(int id) => InMemoryDataStore.Events.FirstOrDefault(e => e.Id == id);

        public void Add(Event evt)
        {
            evt.Id = InMemoryDataStore.Events.Any() ? InMemoryDataStore.Events.Max(e => e.Id) + 1 : 1;
            InMemoryDataStore.Events.Add(evt);
        }

        public void Delete(int id)
        {
            var evt = GetById(id);
            if (evt != null) InMemoryDataStore.Events.Remove(evt);
        }
    }
}
