﻿using ContractMonthlyClaimSystem.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ContractMonthlyClaimSystem.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly IClaimService _claimService;

        public ClaimsController(IClaimService claimService)
        {
            _claimService = claimService;
        }

        [HttpGet]
        public IActionResult SubmitNewClaim()
        {
            ViewBag.Months = GetMonthList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SubmitNewClaim(Claim claim, IFormFile? document)
        {
            if (claim == null)
                return BadRequest("Claim data is missing.");

            if (ModelState.IsValid)
            {
                if (document != null && document.Length > 0)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/documents");
                    Directory.CreateDirectory(uploadsFolder);

                    var safeFileName = Path.GetFileNameWithoutExtension(document.FileName);
                    var extension = Path.GetExtension(document.FileName);
                    var allowedExtensions = new[] { ".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png" };

                    if (!allowedExtensions.Contains(extension.ToLower()))
                    {
                        ModelState.AddModelError("Document", "Invalid file type. Only PDF, DOC, JPG, or PNG allowed.");
                        ViewBag.Months = GetMonthList();
                        return View(claim);
                    }

                    var uniqueFileName = $"{safeFileName}_{Guid.NewGuid()}{extension}";
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        document.CopyTo(stream);
                    }

                    claim.DocumentPath = "/documents/" + uniqueFileName;
                }
                else
                {
                    // If no document is uploaded, leave the path empty
                    claim.DocumentPath = string.Empty;
                }

                claim.ClaimAmount = claim.HoursWorked * claim.HourlyRate;
                claim.Status = "Pending";
                claim.IsApproved = false;

                _claimService.SubmitClaim(claim);
                return RedirectToAction("ClaimSuccess");
            }

            ViewBag.Months = GetMonthList();
            return View(claim);
        }

        public IActionResult ClaimSuccess() => View();

        public IActionResult ViewClaims()
        {
            var claims = _claimService.GetAllClaims();
            return View(claims);
        }

        public IActionResult Approve(int id)
        {
            _claimService.ApproveClaim(id);
            return RedirectToAction("ViewClaims");
        }

        public IActionResult Reject(int id)
        {
            _claimService.RejectClaim(id);
            return RedirectToAction("ViewClaims");
        }

        private List<string> GetMonthList() => new()
        {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        };
    }
}
