﻿using System.Collections.Generic;

namespace ContractMonthlyClaimSystem.Models
{
    public interface IClaimService
    {
        void SubmitClaim(Claim claim);
        IEnumerable<Claim> GetAllClaims();
        void ApproveClaim(int id);
        void RejectClaim(int id);
    }
}
