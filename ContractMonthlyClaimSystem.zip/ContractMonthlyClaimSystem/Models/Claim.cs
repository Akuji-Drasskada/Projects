﻿using System.ComponentModel.DataAnnotations;

namespace ContractMonthlyClaimSystem.Models
{
    public class Claim
    {
        public int ClaimID { get; set; }

        [Required(ErrorMessage = "Lecturer name is required.")]
        public string LecturerName { get; set; }

        [Required(ErrorMessage = "Hours worked is required.")]
        [Range(1, 200, ErrorMessage = "Hours must be between 1 and 200.")]
        public int HoursWorked { get; set; }

        [Required(ErrorMessage = "Hourly rate is required.")]
        [Range(1, 10000, ErrorMessage = "Rate must be between 1 and 10000.")]
        public decimal HourlyRate { get; set; }

        [Required(ErrorMessage = "Month is required.")]
        public string Month { get; set; }

        // Auto-calculated: HoursWorked × HourlyRate
        public decimal ClaimAmount { get; set; }

        // Optional supporting file path
        public string? DocumentPath { get; set; }

        public bool IsApproved { get; set; }

        public string Status { get; set; }

        public Claim()
        {
            Status = "Pending";
            IsApproved = false;
        }
    }
}
