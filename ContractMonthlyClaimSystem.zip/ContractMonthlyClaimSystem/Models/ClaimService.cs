﻿using System.Collections.Generic;
using System.Linq;

namespace ContractMonthlyClaimSystem.Models
{
    public class ClaimService : IClaimService
    {
        // This list holds claims in memory while the app is running.
        private readonly List<Claim> _claims = new();

        public void SubmitClaim(Claim claim)
        {
            claim.ClaimID = _claims.Any() ? _claims.Max(c => c.ClaimID) + 1 : 1;
            _claims.Add(claim);
        }

        public IEnumerable<Claim> GetAllClaims()
        {
            return _claims;
        }

        public void ApproveClaim(int id)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimID == id);
            if (claim != null)
            {
                claim.IsApproved = true;
                claim.Status = "Approved";
            }
        }

        public void RejectClaim(int id)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimID == id);
            if (claim != null)
            {
                claim.IsApproved = false;
                claim.Status = "Rejected";
            }
        }
    }
}
