using ContractMonthlyClaimSystem.Models;

var builder = WebApplication.CreateBuilder(args);

// Register services to the container.
builder.Services.AddControllersWithViews();

// Register in-memory ClaimService as singleton
builder.Services.AddSingleton<IClaimService, ClaimService>();

var app = builder.Build();

// Configure middleware pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts(); // Use HTTP Strict Transport Security in production
}

app.UseHttpsRedirection();        // Redirect HTTP to HTTPS
app.UseStaticFiles();             // Serve static content (CSS, JS, docs, etc.)

app.UseRouting();                 // Enable routing for controllers/views
app.UseAuthorization();          // Placeholder for auth if needed later

// Map default route: Home/Index
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
