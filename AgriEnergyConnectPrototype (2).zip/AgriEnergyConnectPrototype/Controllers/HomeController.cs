﻿using System.Diagnostics;
using AgriEnergyConnectPrototype.Models;
using Microsoft.AspNetCore.Mvc;

namespace AgriEnergyConnectPrototype.Controllers
{
    /// <summary>
    /// Controller responsible for handling general navigation and authentication flow.
    /// Includes landing page, error handling, and role-based redirection.
    /// </summary>
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="HomeController"/> class.
        /// </summary>
        /// <param name="logger">Logger used for tracking user activity and errors.</param>
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Entry point of the application. Displays the homepage or redirects authenticated users to their dashboard.
        /// </summary>
        /// <returns>The homepage view if unauthenticated; otherwise, redirects to the appropriate dashboard.</returns>
        public IActionResult Index()
        {
            // Log access to the homepage
            _logger.LogInformation("User accessed the homepage.");

            // Check if the user is already authenticated by checking session data
            var userRole = HttpContext.Session.GetString("UserRole");

            if (!string.IsNullOrEmpty(userRole))
            {
                return RedirectToRoleDashboard(userRole);
            }

            // If not authenticated, show the landing page
            _logger.LogInformation("Unauthenticated user accessing the landing page.");
            return View();
        }

        /// <summary>
        /// Redirects the authenticated user to their respective dashboard based on their role.
        /// </summary>
        /// <param name="userRole">The role of the authenticated user (e.g., Farmer or Employee).</param>
        /// <returns>Action result that redirects to the correct dashboard or AccessDenied view for unknown roles.</returns>
        private IActionResult RedirectToRoleDashboard(string userRole)
        {
            switch (userRole)
            {
                case Roles.Farmer:
                    _logger.LogInformation("Redirecting authenticated Farmer to Farmer Dashboard.");
                    return RedirectToAction("Index", "Farmer");

                case Roles.Employee:
                    _logger.LogInformation("Redirecting authenticated Employee to Employee Dashboard.");
                    return RedirectToAction("EmpDashboard", "Employee");

                default:
                    _logger.LogWarning($"Unknown user role detected: {userRole}");
                    return RedirectToAction("AccessDenied"); // Prevent unauthorized access
            }
        }

        /// <summary>
        /// Displays the Access Denied page when a user tries to access restricted content without proper permissions.
        /// </summary>
        /// <returns>The Access Denied view.</returns>
        public IActionResult AccessDenied()
        {
            return View();
        }

        /// <summary>
        /// Displays the Privacy Policy page.
        /// </summary>
        /// <returns>The Privacy Policy view.</returns>
        public IActionResult Privacy()
        {
            return View();
        }

        /// <summary>
        /// Handles unexpected errors gracefully by displaying an error view with a request ID.
        /// </summary>
        /// <returns>Error view containing the request identifier for debugging purposes.</returns>
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            // Get the current request's unique identifier
            var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;

            // Log the error with the request ID for easier debugging
            _logger.LogError($"An error occurred. Request ID: {requestId}");

            return View(new ErrorViewModel { RequestId = requestId });
        }
    }

    /// <summary>
    /// Static class defining constants for user roles used throughout the application.
    /// Helps avoid hardcoded strings and improves maintainability.
    /// </summary>
    public static class Roles
    {
        /// <summary>
        /// Represents the Farmer role.
        /// </summary>
        public const string Farmer = "Farmer";

        /// <summary>
        /// Represents the Employee (admin) role.
        /// </summary>
        public const string Employee = "Employee";
    }
}