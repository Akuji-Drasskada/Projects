﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace AgriEnergyConnectPrototype.Extensions
{
    /// <summary>
    /// Provides extension methods for <see cref="IQueryable{T}"/> to support conditional query building.
    /// These extensions help simplify dynamic querying logic, especially when dealing with optional filters.
    /// </summary>
    public static class QueryableExtensions
    {
        /// <summary>
        /// Conditionally applies a where clause to the query if the specified condition is true.
        /// This is useful for building dynamic queries where filters may be optional.
        /// </summary>
        /// <typeparam name="T">The type of the elements of the query.</typeparam>
        /// <param name="query">The source query to which the filter will be applied.</param>
        /// <param name="condition">A boolean indicating whether the filter should be applied.</param>
        /// <param name="predicate">An expression representing the filter condition to apply.</param>
        /// <returns>An IQueryable with the optional filter applied.</returns>
        /// 
        /// <example>
        /// // Only filter by category if it's not null or empty:
        /// var result = db.Products.AsQueryable()
        ///     .WhereIf(!string.IsNullOrEmpty(category), p => p.Category.Contains(category));
        /// </example>
        public static IQueryable<T> WhereIf<T>(this IQueryable<T> query, bool condition, Expression<Func<T, bool>> predicate)
        {
            if (condition)
            {
                return query.Where(predicate);
            }

            return query;
        }
    }
}