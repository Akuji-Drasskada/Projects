﻿using AgriEnergyConnectPrototype.Models;
using Microsoft.EntityFrameworkCore;

namespace AgriEnergyConnectPrototype.Data
{
    /// <summary>
    /// Represents the application's database context.
    /// Manages the connection to the database and tracks entity changes.
    /// </summary>
    public class AppDbContext : DbContext
    {
        /// <summary>
        /// Constructor to initialize the database context with options.
        /// </summary>
        /// <param name="options">Configuration options for the DbContext.</param>
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        /// <summary>
        /// Gets or sets the set of Farmer entities.
        /// </summary>
        public DbSet<Farmer> Farmers { get; set; }

        /// <summary>
        /// Gets or sets the set of Product entities.
        /// </summary>
        public DbSet<Product> Products { get; set; }

        /// <summary>
        /// Configures the model and defines relationships.
        /// </summary>
        /// <param name="modelBuilder">The model builder used to configure entities.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // No seed data. Data will be entered dynamically through forms at runtime.
        }
    }
}
