﻿using AgriEnergyConnectPrototype.Data;
using AgriEnergyConnectPrototype.Models;
using AgriEnergyConnectPrototype.Services;
using BCrypt.Net; // For secure password hashing
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

// Create the builder to configure the host and services
var builder = WebApplication.CreateBuilder(args);

// Add MVC controllers and views support
builder.Services.AddControllersWithViews();

// Enable IHttpContextAccessor so we can access session in services like AuthService
builder.Services.AddHttpContextAccessor();

// Configure session management
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Session timeout duration
    options.Cookie.HttpOnly = true;               // Helps prevent XSS attacks
    options.Cookie.IsEssential = true;            // Always keep session available
});

// Register the AppDbContext using InMemoryDatabase for development/demo purposes
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("AgriDb"));

// Register custom services as scoped (one instance per request)
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<ValidationService>();

// Build the application
var app = builder.Build();

// Seed test data into the database
SeedData(app);

// Configure the middleware pipeline

if (!app.Environment.IsDevelopment())
{
    // Use exception handler and HSTS in production-like environments
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    // Show detailed error page during development
    app.UseDeveloperExceptionPage();
}

// Enforce HTTPS and serve static files (CSS, JS, images)
app.UseHttpsRedirection();
app.UseStaticFiles();

// Enable routing and session
app.UseRouting();
app.UseSession(); // Enables session state middleware
app.UseAuthorization(); // Enables role-based authorization

// Define default route: {controller=Home}/{action=Index}/{id?}
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Start the application
app.Run();

// -------------------------
// 🔧 Helper Methods
// -------------------------

/// <summary>
/// Seeds initial test data into the in-memory database.
/// Ensures consistent demo data between restarts.
/// </summary>
void SeedData(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();

    // Ensure database is created (only applies to InMemory for this project)
    dbContext.Database.EnsureCreated();

    // Seed Farmers if they don't already exist
    var farmersToSeed = new[]
    {
        new Farmer
        {
            Id = 1,
            Name = "John Doe",
            ContactInfo = "john@example.com",
            Username = "john",
            Password = HashPassword("1234"), // Securely hashed password
            Role = "Farmer"
        },
        new Farmer
        {
            Id = 2,
            Name = "Jane Smith",
            ContactInfo = "jane@example.com",
            Username = "jane",
            Password = HashPassword("1234"),
            Role = "Farmer"
        }
    };

    foreach (var farmer in farmersToSeed)
    {
        if (!dbContext.Farmers.Any(f => f.Id == farmer.Id))
        {
            dbContext.Farmers.Add(farmer);
        }
    }

    // Seed Products
    var productsToSeed = new[]
    {
        new Product
        {
            Id = 1,
            Name = "Apple",
            Category = "Fruit",
            ProductionDate = new DateTime(2025, 5, 20),
            FarmerId = 1
        },
        new Product
        {
            Id = 2,
            Name = "Banana",
            Category = "Fruit",
            ProductionDate = new DateTime(2025, 5, 25),
            FarmerId = 1
        },
        new Product
        {
            Id = 3,
            Name = "Carrot",
            Category = "Vegetable",
            ProductionDate = new DateTime(2025, 5, 15),
            FarmerId = 2
        }
    };

    foreach (var product in productsToSeed)
    {
        if (!dbContext.Products.Any(p => p.Id == product.Id))
        {
            dbContext.Products.Add(product);
        }
    }

    // Save all seeded data to the in-memory database
    dbContext.SaveChanges();
}

/// <summary>
/// Hashes a plaintext password using BCrypt for secure storage.
/// This ensures passwords are not stored in plain text.
/// </summary>
string HashPassword(string password)
{
    return BCrypt.Net.BCrypt.HashPassword(password, BCrypt.Net.BCrypt.GenerateSalt());
}