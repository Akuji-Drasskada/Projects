﻿using System;
using System.Linq;
using AgriEnergyConnectPrototype.Data;
using AgriEnergyConnectPrototype.Models;

namespace AgriEnergyConnectPrototype.Services
{
    /// <summary>
    /// Service responsible for validating user input and ensuring data integrity.
    /// Includes validation for farmers, products, and ownership checks.
    /// </summary>
    public class ValidationService
    {
        private readonly AppDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationService"/> class.
        /// </summary>
        /// <param name="context">Database context used for validation queries.</param>
        public ValidationService(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Validates that required farmer fields are provided correctly.
        /// </summary>
        /// <param name="name">Name of the farmer.</param>
        /// <param name="contactInfo">Contact information (e.g., email).</param>
        /// <param name="errorMessage">Output parameter containing any error message if validation fails.</param>
        /// <returns>True if valid; otherwise false.</returns>
        public bool ValidateFarmer(string name, string contactInfo, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(name))
            {
                errorMessage = "Name is required.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(contactInfo))
            {
                errorMessage = "Contact information is required.";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validates that required product fields are provided correctly.
        /// Also checks that the production date is valid and not in the future.
        /// </summary>
        /// <param name="name">Product name.</param>
        /// <param name="category">Product category.</param>
        /// <param name="productionDate">Production date as a string input.</param>
        /// <param name="errorMessage">Output parameter containing any error message if validation fails.</param>
        /// <returns>True if valid; otherwise false.</returns>
        public bool ValidateProduct(string name, string category, string productionDate, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(name))
            {
                errorMessage = "Product name is required.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(category))
            {
                errorMessage = "Product category is required.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(productionDate))
            {
                errorMessage = "Production date is required.";
                return false;
            }

            if (!DateTime.TryParse(productionDate, out var parsedDate))
            {
                errorMessage = "Invalid production date format.";
                return false;
            }

            if (parsedDate > DateTime.Now)
            {
                errorMessage = "Production date cannot be in the future.";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validates that required product fields are provided correctly.
        /// Overloaded method accepting a DateTime instead of a string date.
        /// </summary>
        /// <param name="name">Product name.</param>
        /// <param name="category">Product category.</param>
        /// <param name="productionDate">Production date as a DateTime object.</param>
        /// <param name="errorMessage">Output parameter containing any error message if validation fails.</param>
        /// <returns>True if valid; otherwise false.</returns>
        public bool ValidateProduct(string name, string category, DateTime productionDate, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(name))
            {
                errorMessage = "Product name is required.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(category))
            {
                errorMessage = "Product category is required.";
                return false;
            }

            if (productionDate > DateTime.Now)
            {
                errorMessage = "Production date cannot be in the future.";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Retrieves the name of a farmer based on their ID from the database.
        /// Useful for displaying owner information or logging.
        /// </summary>
        /// <param name="farmerId">The unique ID of the farmer.</param>
        /// <returns>The name of the farmer or null if not found.</returns>
        public string GetFarmerName(int farmerId)
        {
            var farmer = _context.Farmers.FirstOrDefault(f => f.Id == farmerId);
            return farmer?.Name;
        }

        /// <summary>
        /// Checks whether a given product belongs to the specified farmer.
        /// Used to enforce role-based access control for editing/deleting products.
        /// </summary>
        /// <param name="productId">The ID of the product to check.</param>
        /// <param name="farmerId">The ID of the farmer to verify ownership.</param>
        /// <returns>True if the product exists and belongs to the farmer; otherwise false.</returns>
        public bool ValidateProductOwnership(int productId, int farmerId)
        {
            var product = _context.Products.Find(productId);
            return product != null && product.FarmerId == farmerId;
        }
    }
}