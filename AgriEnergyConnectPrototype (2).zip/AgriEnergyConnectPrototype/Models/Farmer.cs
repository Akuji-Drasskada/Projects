﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AgriEnergyConnectPrototype.Models
{
    /// <summary>
    /// Represents a farmer in the system.
    /// Stores personal information and credentials for authentication purposes.
    /// </summary>
    public class Farmer
    {
        /// <summary>
        /// Gets or sets the unique identifier for the farmer.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the full name of the farmer.
        /// This field is required and limited to 60 characters.
        /// </summary>
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(60, ErrorMessage = "Name cannot exceed 60 characters.")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the contact information (e.g., email or phone number) of the farmer.
        /// This field is required and limited to 100 characters.
        /// </summary>
        [Required(ErrorMessage = "Contact information is required.")]
        [StringLength(100, ErrorMessage = "Contact Info cannot exceed 100 characters.")]
        public string ContactInfo { get; set; }

        /// <summary>
        /// Gets or sets the username used by the farmer to log into the system.
        /// This field is required and must be unique in practice.
        /// </summary>
        [Required(ErrorMessage = "Username is required.")]
        [StringLength(40, ErrorMessage = "Username cannot exceed 40 characters.")]
        public string Username { get; set; }

        /// <summary>
        /// Gets or sets the password used by the farmer to authenticate.
        /// ⚠️ Should be hashed in production.
        /// </summary>
        [Required(ErrorMessage = "Password is required.")]
        [StringLength(100, ErrorMessage = "Password cannot exceed 100 characters.")]
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the role of the user (e.g., Farmer or Employee).
        /// Used for access control.
        /// </summary>
        [Required(ErrorMessage = "Role is required.")]
        [StringLength(20, ErrorMessage = "Role cannot exceed 20 characters.")]
        public string Role { get; set; }

        /// <summary>
        /// Optional: List of products created by this farmer (navigation property).
        /// </summary>
        public List<Product> Products { get; set; }
    }
}
