﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;

namespace Prog6211_POE_Part1_St10303286_MokranAitAmara
{
    public class Recipe
    {
    private List<Ingredient> ingredients;
    private List<Step> steps;
    private List<Ingredient> originalIngredients;

    public Recipe()
    {
        ingredients = new List<Ingredient>();
        steps = new List<Step>();
        originalIngredients = new List<Ingredient>();
    }

    public void AddIngredient(Ingredient ingredient)
    {
        ingredients.Add(ingredient);
        originalIngredients.Add(new Ingredient(ingredient.Name, ingredient.Quantity, ingredient.Unit));
    }

    public void AddStep(Step step)
    {
        steps.Add(step);
    }

    public void DisplayRecipe()
    {
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in ingredients)
        {
            Console.WriteLine(ingredient);
        }
        
        Console.WriteLine("\nSteps:");
        for (int i = 0; i < steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {steps[i]}");
        }
    }

    public void ScaleRecipe(double factor)
    {
        foreach (var ingredient in ingredients)
        {
            ingredient.Scale(factor);
        }
    }

    public void ResetQuantities()
    {
        ingredients.Clear();
        foreach (var ingredient in originalIngredients)
        {
            ingredients.Add(new Ingredient(ingredient.Name, ingredient.Quantity, ingredient.Unit));
        }
    }

    public void ClearRecipe()
    {
        ingredients.Clear();
        steps.Clear();
        originalIngredients.Clear();
    }
}

}
