﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Prog6211_POE_Part1_St10303286_MokranAitAmara
{
   

    class MainProgram
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();
            bool running = true;

            while (running)
            {
                Console.WriteLine("Recipe Application");
                Console.WriteLine("1. Add Ingredient");
                Console.WriteLine("2. Add Step");
                Console.WriteLine("3. Display Recipe");
                Console.WriteLine("4. Scale Recipe");
                Console.WriteLine("5. Reset Quantities");
                Console.WriteLine("6. Clear Recipe");
                Console.WriteLine("7. Exit");
                Console.Write("Choose an option: ");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddIngredient(recipe);
                        break;
                    case 2:
                        AddStep(recipe);
                        break;
                    case 3:
                        recipe.DisplayRecipe();
                        break;
                    case 4:
                        ScaleRecipe(recipe);
                        break;
                    case 5:
                        recipe.ResetQuantities();
                        break;
                    case 6:
                        recipe.ClearRecipe();
                        break;
                    case 7:
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void AddIngredient(Recipe recipe)
        {
            Console.Write("Enter ingredient name: ");
            string name = Console.ReadLine();

            Console.Write("Enter quantity: ");
            double quantity = double.Parse(Console.ReadLine());

            Console.Write("Enter unit of measurement: ");
            string unit = Console.ReadLine();

            recipe.AddIngredient(new Ingredient(name, quantity, unit));
        }

        static void AddStep(Recipe recipe)
        {
            Console.Write("Enter step description: ");
            string description = Console.ReadLine();

            recipe.AddStep(new Step(description));
        }

        static void ScaleRecipe(Recipe recipe)
        {
            Console.Write("Enter scaling factor (0.5, 2, 3): ");
            double factor = double.Parse(Console.ReadLine());

            recipe.ScaleRecipe(factor);
        }
    }

}
