﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Prog6211_POE_Part2_St10303286_MokranAitAmara
{
    

    public class RecipeCollection
    {
        private List<Recipe> recipes;

        public RecipeCollection()
        {
            recipes = new List<Recipe>();
        }

        public void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
            recipes = recipes.OrderBy(r => r.Name).ToList();
        }

        public void ListRecipes()
        {
            Console.WriteLine("Recipes:");
            foreach (var recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }

        public Recipe GetRecipe(string name)
        {
            return recipes.FirstOrDefault(r => r.Name == name);
        }
    }

}
