﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;

namespace Prog6211_POE_Part2_St10303286_MokranAitAmara
{


    class MainProgram
    {
 
        static RecipeCollection recipeCollection = new RecipeCollection();

        static void Main(string[] args)
        {
            bool running = true;

            while (running)
            {
                Console.WriteLine("Recipe Application");
                Console.WriteLine("1. Add Recipe");
                Console.WriteLine("2. List Recipes");
                Console.WriteLine("3. View Recipe");
                Console.WriteLine("4. Scale Recipe");
                Console.WriteLine("5. Reset Recipe Quantities");
                Console.WriteLine("6. Clear Recipe");
                Console.WriteLine("7. Exit");
                Console.Write("Choose an option: ");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddRecipe();
                        break;
                    case 2:
                        recipeCollection.ListRecipes();
                        break;
                    case 3:
                        ViewRecipe();
                        break;
                    case 4:
                        ScaleRecipe();
                        break;
                    case 5:
                        ResetRecipeQuantities();
                        break;
                    case 6:
                        ClearRecipe();
                        break;
                    case 7:
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void AddRecipe()
        {
            Console.Write("Enter recipe name: ");
            string name = Console.ReadLine();

            var recipe = new Recipe(name);
            recipe.OnHighCalories += message => Console.WriteLine(message);

            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                AddIngredient(recipe);
            }

            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < stepCount; i++)
            {
                AddStep(recipe);
            }

            recipeCollection.AddRecipe(recipe);
        }

        static void AddIngredient(Recipe recipe)
        {
            Console.Write("Enter ingredient name: ");
            string name = Console.ReadLine();

            Console.Write("Enter quantity: ");
            double quantity = double.Parse(Console.ReadLine());

            Console.Write("Enter unit of measurement: ");
            string unit = Console.ReadLine();

            Console.Write("Enter calories per unit: ");
            int calories = int.Parse(Console.ReadLine());

            Console.Write("Enter food group: ");
            string foodGroup = Console.ReadLine();

            recipe.AddIngredient(new Ingredient(name, quantity, unit, calories, foodGroup));
        }

        static void AddStep(Recipe recipe)
        {
            Console.Write("Enter step description: ");
            string description = Console.ReadLine();

            recipe.AddStep(new Step(description));
        }

        static void ViewRecipe()
        {
            Console.Write("Enter recipe name to view: ");
            string name = Console.ReadLine();

            Recipe recipe = recipeCollection.GetRecipe(name);
            if (recipe != null)
            {
                recipe.DisplayRecipe();
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        static void ScaleRecipe()
        {
            Console.Write("Enter recipe name to scale: ");
            string name = Console.ReadLine();

            Recipe recipe = recipeCollection.GetRecipe(name);
            if (recipe != null)
            {
                Console.WriteLine("Enter scale factor (0.5, 2, or 3): ");
                double factor = double.Parse(Console.ReadLine());
                recipe.ScaleRecipe(factor);
                Console.WriteLine("Recipe scaled successfully.");
                recipe.DisplayRecipe();
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        static void ResetRecipeQuantities()
        {
            Console.Write("Enter recipe name to reset quantities: ");
            string name = Console.ReadLine();

            Recipe recipe = recipeCollection.GetRecipe(name);
            if (recipe != null)
            {
                recipe.ResetQuantities();
                Console.WriteLine("Recipe quantities reset successfully.");
                recipe.DisplayRecipe();
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }

        static void ClearRecipe()
        {
            Console.Write("Enter recipe name to clear: ");
            string name = Console.ReadLine();

            Recipe recipe = recipeCollection.GetRecipe(name);
            if (recipe != null)
            {
                recipe.ClearRecipe();
                Console.WriteLine("Recipe cleared successfully.");
            }
            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }
    }
}
