﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Prog6211_POE_Part2_St10303286_MokranAitAmara
{
    [TestClass]
    public class RecipeTests
    {
        [TestMethod]
        public void CalculateTotalCalories_WithLowCalorieIngredients_ReturnsCorrectTotal()
        {
            // Arrange
            var recipe = new Recipe("Test Recipe");
            recipe.AddIngredient(new Ingredient("Ingredient1", 1, "unit", 50, "Group1"));
            recipe.AddIngredient(new Ingredient("Ingredient2", 2, "unit", 30, "Group2"));

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(110, totalCalories);
        }

        [TestMethod]
        public void CalculateTotalCalories_WithHighCalorieIngredients_TriggersHighCalorieEvent()
        {
            // Arrange
            var recipe = new Recipe("High Calorie Recipe");
            recipe.AddIngredient(new Ingredient("Ingredient1", 3, "unit", 100, "Group1"));
            recipe.AddIngredient(new Ingredient("Ingredient2", 2, "unit", 150, "Group2"));

            bool eventTriggered = false;
            recipe.OnHighCalories += (message) => { eventTriggered = true; };

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(600, totalCalories);
            Assert.IsTrue(eventTriggered);
        }

        [TestMethod]
        public void CalculateTotalCalories_WithoutHighCalorieIngredients_DoesNotTriggerHighCalorieEvent()
        {
            // Arrange
            var recipe = new Recipe("Low Calorie Recipe");
            recipe.AddIngredient(new Ingredient("Ingredient1", 1, "unit", 50, "Group1"));
            recipe.AddIngredient(new Ingredient("Ingredient2", 2, "unit", 30, "Group2"));

            bool eventTriggered = false;
            recipe.OnHighCalories += (message) => { eventTriggered = true; };

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(110, totalCalories);
            Assert.IsFalse(eventTriggered);
        }
    }
}
