﻿using Microsoft.AspNetCore.Mvc;

namespace CommunityCare_Management_System___CCMS__2.Controllers
{

    public class DonationController : Controller
    {
        // GET: Donation/Index
        public IActionResult Index()
        {
            // Return view with list of donations (data fetching logic to be added)
            return View();
        }

        // GET: Donation/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Donation/Create
        [HttpPost]
        public IActionResult Create(string donorName, decimal amount)
        {
            // Add donation logic (save data)
            return RedirectToAction("Index", "Donation");
        }
    }

}
