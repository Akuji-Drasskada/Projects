﻿using Microsoft.AspNetCore.Mvc;

namespace CommunityCare_Management_System___CCMS__2.Controllers
{

    public class ProjectController : Controller
    {
        // GET: Project/Index
        public IActionResult Index()
        {
            // Return view with list of projects (data fetching logic to be added)
            return View();
        }

        // GET: Project/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Project/Create
        [HttpPost]
        public IActionResult Create(string projectName, string description, decimal budget)
        {
            // Add project creation logic (save data)
            return RedirectToAction("Index", "Project");
        }
    }

}
