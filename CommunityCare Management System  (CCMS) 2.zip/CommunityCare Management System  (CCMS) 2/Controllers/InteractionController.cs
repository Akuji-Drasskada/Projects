﻿using Microsoft.AspNetCore.Mvc;

namespace CommunityCare_Management_System___CCMS__2.Controllers
{

    public class InteractionController : Controller
    {
        // GET: Interaction/Index
        public IActionResult Index()
        {
            // Return view with list of interactions (data fetching logic to be added)
            return View();
        }

        // GET: Interaction/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Interaction/Create
        [HttpPost]
        public IActionResult Create(string volunteerName, string beneficiaryName, string interactionDetails)
        {
            // Add interaction creation logic (save data)
            return RedirectToAction("Index", "Interaction");
        }
    }

}
