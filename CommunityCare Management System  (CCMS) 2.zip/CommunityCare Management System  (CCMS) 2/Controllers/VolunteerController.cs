﻿using Microsoft.AspNetCore.Mvc;

namespace CommunityCare_Management_System___CCMS__2.Controllers
{

    public class VolunteerController : Controller
    {
        // GET: Volunteer/Index
        public IActionResult Index()
        {
            // Return view with list of volunteers (data fetching logic to be added)
            return View();
        }

        // GET: Volunteer/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Volunteer/Create
        [HttpPost]
        public IActionResult Create(string name, string email)
        {
            // Add volunteer creation logic (save data)
            return RedirectToAction("Index", "Volunteer");
        }
    }

}
