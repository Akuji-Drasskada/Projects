﻿using Microsoft.AspNetCore.Mvc;

namespace CommunityCare_Management_System___CCMS__2.Controllers
{
    using Microsoft.AspNetCore.Mvc;

    public class EmployeeController : Controller
    {
        // GET: Employee/Index
        public IActionResult Index()
        {
            // Return view with list of employees (data fetching logic to be added)
            return View();
        }

        // GET: Employee/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public IActionResult Create(string employeeName, string position)
        {
            // Add employee creation logic (save data)
            return RedirectToAction("Index", "Employee");
        }
    }

}
