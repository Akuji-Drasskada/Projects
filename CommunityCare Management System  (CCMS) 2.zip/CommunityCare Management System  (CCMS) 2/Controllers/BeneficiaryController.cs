﻿using Microsoft.AspNetCore.Mvc;

namespace CommunityCare_Management_System___CCMS__2.Controllers
{

    public class BeneficiaryController : Controller
    {
        // GET: Beneficiary/Index
        public IActionResult Index()
        {
            // Return view with list of beneficiaries (data fetching logic to be added)
            return View();
        }

        // GET: Beneficiary/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Beneficiary/Create
        [HttpPost]
        public IActionResult Create(string name, string email)
        {
            // Add beneficiary creation logic (save data)
            return RedirectToAction("Index", "Beneficiary");
        }
    }

}
