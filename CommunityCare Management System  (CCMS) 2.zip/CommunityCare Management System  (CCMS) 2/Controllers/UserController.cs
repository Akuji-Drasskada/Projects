﻿using Microsoft.AspNetCore.Mvc;

namespace CommunityCare_Management_System___CCMS__2.Controllers
{

    public class UserController : Controller
    {
        // GET: User/Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: User/Login
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // Add logic for user authentication
            // For now, just return to Home page after login
            return RedirectToAction("Index", "Home");
        }

        // GET: User/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: User/Register
        [HttpPost]
        public IActionResult Register(string username, string email, string password)
        {
            // Add logic for user registration
            // For now, just return to Home page after registration
            return RedirectToAction("Index", "Home");
        }
    }
}

