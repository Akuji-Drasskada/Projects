package com.example.tictactoe_game

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var buttons: Array<Array<Button>>
    private lateinit var textPlayerScore: TextView
    private lateinit var textComputerScore: TextView
    private lateinit var resetButton: Button

    private var board = Array(3) { arrayOfNulls<String>(3) }
    private var playerScore = 0
    private var computerScore = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textPlayerScore = findViewById(R.id.textPlayerScore)
        textComputerScore = findViewById(R.id.textComputerScore)
        resetButton = findViewById(R.id.resetButton)

        buttons = Array(3) { row ->
            Array(3) { col ->
                val idName = "button$row$col"
                val resID = resources.getIdentifier(idName, "id", packageName)
                findViewById(resID)
            }
        }

        initBoard()

        resetButton.setOnClickListener {
            playerScore = 0
            computerScore = 0
            updateScores()
            resetBoard()
        }
    }

    private fun initBoard() {
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i][j].text = ""
                buttons[i][j].setTextColor(Color.BLACK)
                board[i][j] = null

                buttons[i][j].setOnClickListener {
                    if (buttons[i][j].text.isEmpty()) {
                        makeMove(i, j, isPlayer = true)
                        if (!checkGameEnd()) {
                            simulateComputerMove()
                        }
                    }
                }
            }
        }
    }

    private fun makeMove(row: Int, col: Int, isPlayer: Boolean) {
        val symbol = if (isPlayer) "X" else "O"
        val color = if (isPlayer) Color.RED else Color.BLUE

        buttons[row][col].text = symbol
        buttons[row][col].setTextColor(color)
        board[row][col] = symbol
    }

    private fun simulateComputerMove() {
        val emptyCells = mutableListOf<Pair<Int, Int>>()

        for (i in 0..2) {
            for (j in 0..2) {
                if (board[i][j] == null) {
                    emptyCells.add(Pair(i, j))
                }
            }
        }

        if (emptyCells.isNotEmpty()) {
            val (row, col) = emptyCells.random()
            makeMove(row, col, isPlayer = false)
            checkGameEnd()
        }
    }

    private fun checkGameEnd(): Boolean {
        val winner = getWinner()
        if (winner != null) {
            if (winner == "X") {
                playerScore++
            } else if (winner == "O") {
                computerScore++
            }
            updateScores()
            resetBoard()
            return true
        } else if (isBoardFull()) {
            resetBoard()
            return true
        }
        return false
    }

    private fun updateScores() {
        textPlayerScore.text = "Player: $playerScore"
        textComputerScore.text = "Computer: $computerScore"
    }

    private fun isBoardFull(): Boolean {
        for (row in board) {
            for (cell in row) {
                if (cell == null) return false
            }
        }
        return true
    }

    private fun getWinner(): String? {
        val lines = listOf(
            // Rows
            listOf(board[0][0], board[0][1], board[0][2]),
            listOf(board[1][0], board[1][1], board[1][2]),
            listOf(board[2][0], board[2][1], board[2][2]),
            // Columns
            listOf(board[0][0], board[1][0], board[2][0]),
            listOf(board[0][1], board[1][1], board[2][1]),
            listOf(board[0][2], board[1][2], board[2][2]),
            // Diagonals
            listOf(board[0][0], board[1][1], board[2][2]),
            listOf(board[0][2], board[1][1], board[2][0])
        )

        for (line in lines) {
            if (line[0] != null && line[0] == line[1] && line[1] == line[2]) {
                return line[0]
            }
        }
        return null
    }

    private fun resetBoard() {
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i][j].text = ""
                board[i][j] = null
            }
        }
    }
}
