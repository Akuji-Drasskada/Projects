using Azure.Storage.Blobs;
using ABC_RETAIL_APPLICATION_V_1_.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Retrieve and validate configuration settings for Azure File Storage
string storageAccountName = builder.Configuration["AzureFileStorage:AccountName"];
string storageAccountKey = builder.Configuration["AzureFileStorage:AccountKey"];
string contractFileShareName = builder.Configuration["AzureFileStorage:ContractFileShareName"];
string logFileShareName = builder.Configuration["AzureFileStorage:LogFileShareName"]; // Ensure this is added to configuration

// Register AzureFileService for contract files
builder.Services.AddSingleton(new AzureFileService(storageAccountName, storageAccountKey, contractFileShareName));

// Register AzureLog_FileService for log files
builder.Services.AddSingleton(new AzureLog_FileService(storageAccountName, storageAccountKey, logFileShareName));

// Configure BlobServiceClient
var blobServiceClient = new BlobServiceClient(builder.Configuration.GetConnectionString("AzureBlobStorage"));
builder.Services.AddSingleton(blobServiceClient);
builder.Services.AddScoped<AzureBlobService>();

// Configure QueueStorage for queues
var queueConnectionString = builder.Configuration.GetConnectionString("AzureQueueConnectionString");
if (string.IsNullOrEmpty(queueConnectionString))
{
    throw new ArgumentNullException(nameof(queueConnectionString), "Azure Queue connection string is not configured.");
}

var orderQueueName = builder.Configuration["AzureQueueSettings:OrderQueueName"];
var inventoryQueueName = builder.Configuration["AzureQueueSettings:InventoryQueueName"];
var transactionQueueName = builder.Configuration["AzureQueueSettings:TransactionQueueName"];

if (string.IsNullOrEmpty(orderQueueName) || string.IsNullOrEmpty(inventoryQueueName) || string.IsNullOrEmpty(transactionQueueName))
{
    throw new ArgumentNullException("One or more queue names are not configured.");
}

// Register AzureQueueService for multiple queues
builder.Services.AddSingleton(provider => new AzureQueueService(queueConnectionString, orderQueueName));
builder.Services.AddSingleton(provider => new AzureQueueService(queueConnectionString, inventoryQueueName));
builder.Services.AddSingleton(provider => new AzureQueueService(queueConnectionString, transactionQueueName));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "contractFile",
    pattern: "ContractFile/{action=UploadContractFile}/{id?}",
    defaults: new { controller = "ContractFile" });

app.MapControllerRoute(
    name: "logFile",
    pattern: "LogFile/{action=UploadLogFile}/{id?}",
    defaults: new { controller = "LogFile" });

app.Run();
