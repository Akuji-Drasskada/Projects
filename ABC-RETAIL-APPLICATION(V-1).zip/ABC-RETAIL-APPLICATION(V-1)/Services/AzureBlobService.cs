﻿ using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace ABC_RETAIL_APPLICATION_V_1_.Services
{
    public class AzureBlobService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly ILogger<AzureBlobService> _logger;

        public AzureBlobService(BlobServiceClient blobServiceClient, ILogger<AzureBlobService> logger)
        {
            _blobServiceClient = blobServiceClient;
            _logger = logger;
        }

        public async Task<string> UploadFileAsync(IFormFile file, string containerName)
        {
            try
            {
                // Get the container client
                var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);

                // Create the container if it does not exist
                await containerClient.CreateIfNotExistsAsync();

                // Set the content type
                var blobClient = containerClient.GetBlobClient(file.FileName);

                // Open the file stream and upload
                await using (var stream = file.OpenReadStream())
                {
                    await blobClient.UploadAsync(stream, overwrite: true);
                }

                _logger.LogInformation($"File '{file.FileName}' uploaded successfully to container '{containerName}'.");

                return blobClient.Uri.ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error uploading file '{file?.FileName}' to container '{containerName}'.");
                throw;
            }
        }
    }
}
