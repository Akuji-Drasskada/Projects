﻿using Azure.Storage.Files.Shares;
using Azure.Storage;
using Azure;

namespace ABC_RETAIL_APPLICATION_V_1_.Services
{
    public class AzureFileService
    {
        private readonly string _storageAccountName;
        private readonly string _storageAccountKey;
        private readonly string _contractFileShareName;

        public AzureFileService(string storageAccountName, string storageAccountKey, string contractFileShareName)
        {
            _storageAccountName = storageAccountName;
            _storageAccountKey = storageAccountKey;
            _contractFileShareName = contractFileShareName;
        }

        public async Task UploadContractFileAsync(string fileName, Stream fileStream)
        {
            string shareUri = $"https://customerdetails22.file.core.windows.net/contracts";

            ShareClient share = new ShareClient(new Uri(shareUri), new StorageSharedKeyCredential(_storageAccountName, _storageAccountKey));
            ShareDirectoryClient directory = share.GetRootDirectoryClient();
            ShareFileClient file = directory.GetFileClient(fileName);

            fileStream.Position = 0;
            await file.CreateAsync(fileStream.Length);
            await file.UploadRangeAsync(new HttpRange(0, fileStream.Length), fileStream);
        }
    }
}
