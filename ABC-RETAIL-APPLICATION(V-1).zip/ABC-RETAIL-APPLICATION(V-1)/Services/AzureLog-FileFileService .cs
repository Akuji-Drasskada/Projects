﻿using Azure.Storage.Files.Shares;
using Azure.Storage;
using System;
using System.IO;
using System.Threading.Tasks;
using Azure;

namespace ABC_RETAIL_APPLICATION_V_1_.Services
{
    public class AzureLog_FileService
    {
        private readonly string _storageAccountName;
        private readonly string _storageAccountKey;
        private readonly string _log_FileShareName;

        public AzureLog_FileService(string storageAccountName, string storageAccountKey, string logFileShareName)
        {
            _storageAccountName = storageAccountName;
            _storageAccountKey = storageAccountKey;
            _log_FileShareName = logFileShareName;
        }

        public async Task UploadLogFileAsync(string fileName, Stream fileStream)
        {
            string shareUri = $"https://customerdetails22.file.core.windows.net/log-files";

            ShareClient share = new ShareClient(new Uri(shareUri), new StorageSharedKeyCredential(_storageAccountName, _storageAccountKey));
            ShareDirectoryClient directory = share.GetRootDirectoryClient();
            ShareFileClient file = directory.GetFileClient(fileName);

            fileStream.Position = 0;
            await file.CreateAsync(fileStream.Length);
            await file.UploadRangeAsync(new HttpRange(0, fileStream.Length), fileStream);
        }
    }
}
