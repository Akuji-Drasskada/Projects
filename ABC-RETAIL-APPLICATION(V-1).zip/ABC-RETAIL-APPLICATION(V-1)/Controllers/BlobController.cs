﻿using ABC_RETAIL_APPLICATION_V_1_.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace ABC_RETAIL_APPLICATION_V_1_.Controllers
{
    public class BlobController : Controller
    {
        private readonly AzureBlobService _azureBlobService;

        public BlobController(AzureBlobService azureBlobService)
        {
            _azureBlobService = azureBlobService;
        }

        public IActionResult UploadIMG()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadIMG(IFormFile file)
        {
            if (file != null)
            {
                var result = await _azureBlobService.UploadFileAsync(file, "images");
                ViewBag.Message = "Uploaded successfully! URL: " + result;
            }
            else
            {
                ViewBag.Message = "Please select a file to upload.";
            }

            return View();
        }

        public IActionResult UploadMultimedia()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadMultimedia(IFormFile file)
        {
            if (file != null)
            {
                var result = await _azureBlobService.UploadFileAsync(file, "multimedia");
                ViewBag.Message = "Uploaded successfully! URL: " + result;
            }
            else
            {
                ViewBag.Message = "Please select a multimedia file to upload.";
            }

            return View();
        }
    }
}
