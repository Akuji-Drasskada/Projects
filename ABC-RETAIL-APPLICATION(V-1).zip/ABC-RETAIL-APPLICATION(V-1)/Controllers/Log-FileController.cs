﻿using ABC_RETAIL_APPLICATION_V_1_.Services;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Threading.Tasks;

namespace ABC_RETAIL_APPLICATION_V_1_.Controllers
{
    public class LogFileController : Controller
    {
        private readonly AzureLog_FileService _azureLogFileService;

        public LogFileController(AzureLog_FileService azureLogFileService)
        {
            _azureLogFileService = azureLogFileService;
        }

        [HttpGet]
        public IActionResult UploadLogFile()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadLogFile(string fileName, IFormFile file)
        {
            if (string.IsNullOrEmpty(fileName) || file == null || file.Length == 0)
            {
                ModelState.AddModelError(string.Empty, "File name and file content are required.");
                return View();
            }

            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);
                await _azureLogFileService.UploadLogFileAsync(fileName, stream);
            }

            ViewBag.Message = "Log file successfully uploaded!";
            return View();
        }
    }
}
