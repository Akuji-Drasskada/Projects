﻿using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using ABC_RETAIL_APPLICATION_V_1_.Models;

namespace ABC_RETAIL_APPLICATION_V_1_.Controllers
{
    public class ProductsController : Controller
    {
        private readonly string _storageAccountConnectionString;
        private readonly string _tableName = "Products";
        private readonly TableClient _tableClient;

        public ProductsController(IConfiguration configuration)
        {
            _storageAccountConnectionString = configuration["AzureStorage:ConnectionString"];
            _tableClient = new TableClient(_storageAccountConnectionString, _tableName);
            _tableClient.CreateIfNotExists();
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductDetails products)
        {
            if (ModelState.IsValid)
            {
                await _tableClient.AddEntityAsync(products);
                return RedirectToAction(nameof(Success));


            }
            return View(products);
        }
        public IActionResult Success()
        {
            return View();
        }
    }
}
