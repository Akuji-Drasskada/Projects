﻿using ABC_RETAIL_APPLICATION_V_1_.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Threading.Tasks;

namespace ABC_RETAIL_APPLICATION_V_1_.Controllers
{
    public class ContractFileController : Controller
    {
        private readonly AzureFileService _azureFileService;

        public ContractFileController(AzureFileService azureFileService)
        {
            _azureFileService = azureFileService;
        }

        [HttpGet]
        public IActionResult UploadContractFile()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadContractFile(string fileName, IFormFile file)
        {
            if (string.IsNullOrEmpty(fileName) || file == null || file.Length == 0)
            {
                ModelState.AddModelError(string.Empty, "File name and file content are required.");
                return View();
            }

            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);
                // Use the correct method to upload the file
                await _azureFileService.UploadContractFileAsync(fileName, stream);
            }

            ViewBag.Message = "Contract file successfully uploaded!";
            return View();
        }
    }
}
