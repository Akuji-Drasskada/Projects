﻿using Microsoft.AspNetCore.Mvc;
using ABC_RETAIL_APPLICATION_V_1_.Models;
using ABC_RETAIL_APPLICATION_V_1_.Services;

namespace ABC_RETAIL_APPLICATION_V_1_.Controllers
{
    public class QueueController : Controller
    {
        private readonly AzureQueueService _orderQueueService;
        private readonly AzureQueueService _inventoryQueueService;
        private readonly AzureQueueService _transactionQueueService;

        public QueueController(
            AzureQueueService orderQueueService,
            AzureQueueService inventoryQueueService,
            AzureQueueService transactionQueueService)
        {
            _orderQueueService = orderQueueService;
            _inventoryQueueService = inventoryQueueService;
            _transactionQueueService = transactionQueueService;
        }

        public IActionResult QueuePage()
        {
            return View();
        }

        public IActionResult TransactionPage()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateTransaction(Transaction transaction)
        {
            transaction.TransactionID = Guid.NewGuid().ToString();
            await _transactionQueueService.SendMessageAsync(transaction);
            return RedirectToAction("TransactionPage");
        }

        // Add other actions for Order and Inventory as needed
    }
}
