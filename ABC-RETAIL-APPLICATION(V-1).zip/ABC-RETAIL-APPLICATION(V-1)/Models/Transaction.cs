﻿namespace ABC_RETAIL_APPLICATION_V_1_.Models
{
    public class Transaction
    {
        public string TransactionID { get; set; }
        public string PaymentMethod { get; set; }
        public decimal Amount { get; set; }
        public string Product { get; set; }
        public string DeliveryType { get; set; }
        public int Quantity { get; set; }
    }
}
